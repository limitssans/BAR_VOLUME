data class Shoes(
    var name: String = "",
    var price: String = "",
    var photo: Int = 0
)